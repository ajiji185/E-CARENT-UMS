package com.tryapp.myapplication3.e_carrentums;

public class Dummylist {

    public String Name;

    public Dummylist(String name) {
        Name = name;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public Dummylist() {
    }
}
