package com.tryapp.myapplication3.e_carrentums;

public class message {
    public String ID_Msg;
    public String Message_details;


    public message(String ID_Msg, String message_details) {
        this.ID_Msg = ID_Msg;
        Message_details = message_details;
    }


}
