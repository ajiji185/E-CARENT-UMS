package com.tryapp.myapplication3.e_carrentums;

public class motorcycle {
    public String UserMotor_ID;
    public String Motor_id;
    public String MotorcycleName;
    public String MotorTransmission;
    public String MotorPrice;
    public String MotorAvailability;
    public String MotorMatric;
    public String PickupMotor;
    public String ownerMotorNumberPhone;
    public String MotorImageUrl;
    public String MotorPlateNumber;

    public motorcycle() {
    }

    public String getUserMotor_ID() {
        return UserMotor_ID;
    }

    public void setUserMotor_ID(String userMotor_ID) {
        UserMotor_ID = userMotor_ID;
    }

    public String getMotor_id() {
        return Motor_id;
    }

    public void setMotor_id(String motor_id) {
        Motor_id = motor_id;
    }

    public String getMotorcycleName() {
        return MotorcycleName;
    }

    public void setMotorcycleName(String motorcycleName) {
        MotorcycleName = motorcycleName;
    }

    public String getMotorTransmission() {
        return MotorTransmission;
    }

    public void setMotorTransmission(String motorTransmission) {
        MotorTransmission = motorTransmission;
    }

    public String getMotorPrice() {
        return MotorPrice;
    }

    public void setMotorPrice(String motorPrice) {
        MotorPrice = motorPrice;
    }

    public String getMotorAvailability() {
        return MotorAvailability;
    }

    public void setMotorAvailability(String motorAvailability) {
        MotorAvailability = motorAvailability;
    }

    public String getMotorMatric() {
        return MotorMatric;
    }

    public void setMotorMatric(String motorMatric) {
        MotorMatric = motorMatric;
    }

    public String getPickupMotor() {
        return PickupMotor;
    }

    public void setPickupMotor(String pickupMotor) {
        PickupMotor = pickupMotor;
    }

    public String getOwnerMotorNumberPhone() {
        return ownerMotorNumberPhone;
    }

    public void setOwnerMotorNumberPhone(String ownerMotorNumberPhone) {
        this.ownerMotorNumberPhone = ownerMotorNumberPhone;
    }

    public String getMotorImageUrl() {
        return MotorImageUrl;
    }

    public void setMotorImageUrl(String motorImageUrl) {
        MotorImageUrl = motorImageUrl;
    }

    public String getMotorPlateNumber() {
        return MotorPlateNumber;
    }

    public void setMotorPlateNumber(String motorPlateNumber) {
        MotorPlateNumber = motorPlateNumber;
    }
}
